@echo off
rem (Opcional) El gateway termico arranca al iniciar sesion, aunque nadie abra la app.
rem Para quitarlo: powershell -ExecutionPolicy Bypass -File gateway\iniciar-con-windows.ps1 -Quitar
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File gateway\iniciar-con-windows.ps1
pause
