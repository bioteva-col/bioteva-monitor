// BioTeva Monitor — service worker de la extensión.
// - Al pulsar el ícono: trae al frente la pestaña de la app (o la abre).
// - Al instalar: abre la app.
// - Al iniciar Chrome: si el monitoreo estaba en curso, reabre la app (fijada) y
//   ésta lo reanuda sola.
// Sin permisos sobre pestañas ni páginas del usuario: solo ve sus propias pestañas.
const APP_URL = chrome.runtime.getURL("index.html");

async function appTab() {
  try {
    const ctx = await chrome.runtime.getContexts({ contextTypes: ["TAB"] });
    const c = ctx.find((x) => x.documentUrl && x.documentUrl.startsWith(APP_URL) && x.tabId >= 0);
    return c ? c.tabId : null;
  } catch (e) {
    return null;
  }
}

async function openApp({ pinned = false } = {}) {
  const id = await appTab();
  if (id != null) {
    const tab = await chrome.tabs.update(id, { active: true });
    if (tab && tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
    return;
  }
  const tab = await chrome.tabs.create({ url: APP_URL, pinned });
  if (tab && tab.id != null) chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {});
}

chrome.action.onClicked.addListener(() => openApp());

chrome.runtime.onInstalled.addListener((d) => {
  if (d.reason === "install") openApp();
});

chrome.runtime.onStartup.addListener(async () => {
  const { running } = await chrome.storage.local.get("running");
  if (running) openApp({ pinned: true });
});
