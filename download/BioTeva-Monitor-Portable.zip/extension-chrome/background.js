// Al pulsar el ícono de la extensión se abre la app en una pestaña.
// Sin permisos extra: la extensión no lee el historial ni las pestañas del usuario.
const APP_URL = chrome.runtime.getURL("index.html");
chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: APP_URL }));
chrome.runtime.onInstalled.addListener((d) => { if (d.reason === "install") chrome.tabs.create({ url: APP_URL }); });
