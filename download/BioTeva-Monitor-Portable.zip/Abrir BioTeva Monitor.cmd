@echo off
rem ============================================================
rem  BioTeva Monitor (portatil)
rem  - Abre la app directo desde el archivo, en ventana propia de Chrome.
rem  - Si hay Node.js, inicia oculto el gateway termico (lamparas HS105).
rem ============================================================
title BioTeva Monitor
cd /d "%~dp0"

powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:4479/api/status' | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  where node >nul 2>nul && powershell -NoProfile -Command "Start-Process -FilePath 'node' -ArgumentList 'gateway\heater-gateway.mjs' -WorkingDirectory '%CD%' -WindowStyle Hidden"
)

for /f "delims=" %%U in ('powershell -NoProfile -Command "([Uri](Resolve-Path 'app\index.html').Path).AbsoluteUri"') do set "APPURL=%%U"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app=%APPURL%
) else (
  echo No se encontro Google Chrome. Se abrira con el navegador predeterminado.
  start "" "%APPURL%"
)
exit /b 0
