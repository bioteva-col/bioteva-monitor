@echo off
rem Abre BioTeva Monitor sin instalar (gateway termico oculto si hay Node.js).
rem Para que arranque solo al encender el equipo, usa "INSTALAR BioTeva Monitor.cmd".
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File gateway\iniciar.ps1
