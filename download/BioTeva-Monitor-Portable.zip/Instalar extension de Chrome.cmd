@echo off
rem Instala la extension de Chrome de BioTeva Monitor desde una carpeta fija
rem (%LOCALAPPDATA%\BioTeva\extension-chrome) y abre chrome://extensions.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File gateway\instalar-extension.ps1
pause
