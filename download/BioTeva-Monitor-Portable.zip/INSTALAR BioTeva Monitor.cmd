@echo off
rem Instala BioTeva Monitor para que funcione SIEMPRE en este computador:
rem copia todo a %LOCALAPPDATA%\BioTeva, crea el icono del escritorio y lo deja
rem arrancando solo al encender (app + gateway termico vigilado).
rem Para quitar el inicio automatico: powershell -ExecutionPolicy Bypass -File gateway\instalar.ps1 -Quitar
title Instalar BioTeva Monitor
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File gateway\instalar.ps1
if errorlevel 1 ( echo. & echo Hubo un error: revisa el mensaje de arriba. & pause & exit /b 1 )
echo.
echo Abriendo BioTeva Monitor...
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%LOCALAPPDATA%\BioTeva\iniciar.ps1"
pause
