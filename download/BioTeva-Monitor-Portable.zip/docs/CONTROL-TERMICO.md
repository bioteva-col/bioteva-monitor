# BioTeva — control térmico de cajas (Acheta domesticus + TP-Link HS105)

## Principio

**OUT = temperatura de la caja** (sonda dentro de la caja) es la única variable que
enciende o apaga la lámpara. **IN = ambiente**: se muestra y se registra, pero un IN
bajo no enciende la calefacción si la caja ya está bien.

```
cámara → OCR (HTC-2: IN / OUT / HR) → app → gateway térmico local → HS105 → lámpara
                                          └→ histórico, gráficas, análisis
```

## Componentes

| Pieza | Dónde | Qué hace |
|---|---|---|
| Motor del termostato | `src/web/public/monitor/js/thermal.js` | Perfiles, histéresis, confirmaciones, seguridad, falla del sensor, análisis. Lo usan la app (simulador) y el gateway: mismas reglas. |
| Gateway térmico | `scripts/heater-gateway.mjs` (`npm run termico`) | Corre en el computador de las cajas, solo en `127.0.0.1:4479`. Recibe las lecturas, decide cada 5 s y acciona el HS105 por la red local (protocolo Kasa, TCP 9999). **El HS105 nunca se expone a internet.** |
| Pantalla | pestaña **Control térmico** + panel en el Dashboard | Estado por caja, modos AUTO / MANUAL ON / MANUAL OFF, gráfica OUT/IN con franjas de calefacción, simulador, perfiles, parámetros, registro. |

El acceso directo **BioTeva Monitor** abre la app directo desde el archivo (sin servidor
web) e inicia el gateway oculto. Para que el gateway arranque al encender el equipo,
aunque nadie abra la app: `powershell -ExecutionPolicy Bypass -File deploy\instalar-inicio-automatico.ps1`.

Datos del gateway: `%APPDATA%\BioTeva\termico\` (`config.json`, `state.json`, `events.jsonl`).

## Perfiles iniciales (editables en Control térmico → Perfiles)

| Etapa | Objetivo | Rango operativo | Enciende ≤ | Apaga ≥ | Alerta | Crítico | Recupera ≤ |
|---|---|---|---|---|---|---|---|
| Huevos / incubación (HR 65–75 %) | 30 | 29–31 | 29.5 | 30.5 | 32 | 33 | 30.5 |
| Ninfas (juveniles) | 30 | 28–32 | 29 | 31 | 32.5 | 33 | 30.5 |
| Adultos / reproducción | 30 | 28–32 | 29 | 31 | 32.5 | 33 | 30.5 |

Son **parámetros iniciales de producción**, no límites biológicos absolutos. 33 °C es un
umbral de seguridad inicial (no una temperatura letal demostrada). Referencias:
Insects 2023 14(7):588; Animals 2024 14(15):2176; J. Insect Physiol. 2007. Los grillos
tienen metamorfosis incompleta: la app habla de **ninfas**, no de larvas.

## Reglas

1. **Histéresis:** enciende con OUT ≤ «enciende», apaga con OUT ≥ «apaga»; en medio mantiene el estado.
2. **Confirmación:** alta 30 s, baja 60 s (configurable). **Intervalo mínimo** entre conmutaciones: 120 s.
3. **Seguridad:** OUT ≥ crítico → apagado inmediato (también en modo manual), estado `SAFETY_SHUTDOWN`, alerta crítica. No se reanuda hasta OUT ≤ recuperación (segunda histéresis).
4. **Falla del sensor de caja** (sin lecturas, desactualizada, NaN, imposible, congelada): `SENSOR_ERROR`, "Temperatura de caja no disponible" y estrategia configurable: apagar (por defecto), mantener o ciclo de seguridad ON/OFF.
5. **HS105:** cada comando se verifica consultando el enchufe. Si no se confirma → `UNKNOWN` / `UNREACHABLE` + alerta; nunca se afirma "apagado" sin confirmación.
6. **Lecturas simuladas** nunca accionan un HS105 real.
7. **Consumo:** se registra el tiempo encendido; no se inventan kWh, W ni A (el HS105 no los mide).

Razones registradas: `LOW_TEMPERATURE`, `HIGH_TEMPERATURE`, `CRITICAL_TEMPERATURE`, `MANUAL_ON`,
`MANUAL_OFF`, `AUTO_CONTROL`, `SAFETY_SHUTDOWN`, `SENSOR_ERROR`, `DEVICE_UNREACHABLE`, `RECOVERY`.

## Configurar un HS105

1. Configúralo con la app Kasa en la Wi-Fi de 2,4 GHz del computador de las cajas.
2. En el router, reserva una IP fija para el enchufe.
3. Control térmico → *Cajas, sensores y enchufes*: tipo **TP-Link HS105**, escribe la IP y pulsa **Probar**.

> **No verificado con el HS105 físico:** el protocolo implementado es el local clásico de Kasa
> (probado contra un enchufe simulado). Algunos firmwares nuevos de TP-Link usan otro método
> de autenticación (KLAP); si **Probar** no responde con tu enchufe, la alternativa es usar
> Home Assistant o `python-kasa` como puente.

## Análisis

La gráfica muestra OUT, IN, umbrales y franjas de calefacción encendida. El análisis calcula:
% del tiempo en rango, ciclos, duración media ON/OFF, % encendido, °C/min al calentar y al
enfriar, y minutos para subir/bajar 1 °C, por caja. Sirve para ajustar los perfiles con
datos propios de Bioteva.

## Pruebas

`tests/monitor/thermal.test.ts`: temperatura baja/normal/alta/crítica, recuperación,
histéresis, confirmaciones, intervalo mínimo, sensor caído (incluida la app cerrada),
HS105 inalcanzable, modo manual/automático, múltiples cajas, lecturas simuladas vs. HS105
real, tiempo encendido y el protocolo Kasa contra un enchufe simulado por TCP.
