# BioTeva Monitor — monitoreo ambiental por cámara

Lee con la cámara del computador los termohigrómetros **HTC-2** de las cajas de
grillos (temperatura IN, temperatura OUT, humedad y hora), guarda el histórico y
genera alertas, gráficas, reportes y Excel. **Todo el procesamiento es local**:
el video nunca sale del equipo y no se necesita internet.

Código: `src/web/public/monitor/` (HTML + JavaScript sin dependencias ni paso de build).

## 1. Cómo abrirlo

| Forma | Cómo | Para qué |
|---|---|---|
| **En Chrome** | `npm run monitor` → abre `http://localhost:4478/` | Uso diario sin el panel ejecutivo. |
| **Desde el panel** | `npm run web` → pestaña **Monitoreo ↗** (`http://localhost:4477/monitor/`) | Si ya usas el panel (pide su contraseña). |
| **App de escritorio (PWA)** | Con la app abierta en Chrome: botón **⊕ Instalar app** o menú ⋮ → *Transmitir, guardar y compartir* → *Instalar página como app* | Ventana propia, ícono en escritorio / menú Inicio, abre sin internet. |
| **Acceso directo (recomendado)** | Doble clic en **BioTeva Monitor** del escritorio (o `deploy/run-monitor.cmd`) | Abre la app **directo desde el archivo, sin servidor web**, en ventana propia de Chrome, e inicia oculto el gateway térmico (lámparas HS105, ver [CONTROL-TERMICO.md](CONTROL-TERMICO.md)). Solo depende de Chrome, la cámara y los sensores. |
| **Extensión de Chrome** | `npm run build:monitor` → carpeta `dist/monitor-extension/` (o el `.zip`). En `chrome://extensions` activa *Modo de desarrollador* → *Cargar descomprimida* → elige la carpeta | Funciona sin ningún servidor. Se abre desde el ícono de la extensión. |

> **Importante:** cada forma guarda sus datos por separado (la base vive en el
> navegador). Elige una para el uso diario; para mover datos usa
> *Configuración → Datos y respaldo*.

La cámara solo funciona en orígenes seguros: extensión, `http://localhost` o
`https://`. Abrirlo por la IP de la red local (`http://192.168…`) **no** permite la cámara.

## 2. Activar la cámara

1. Pestaña **Cámara** → Fuente de imagen: **Cámara**.
2. Elige el modo: *Una cámara → Sensor A + B* o *Dos cámaras → A y B*.
3. Pulsa **Activar cámara** y acepta el permiso de Chrome.
   Estados: `CAMERA OFF`, `CAMERA STARTING`, `CAMERA ACTIVE`, `CAMERA ERROR` (con la causa: permiso denegado, cámara ocupada por otra app, desconectada…).
4. Elige cámara, resolución y FPS de la vista previa. Los nombres aparecen después del primer permiso.
5. **Captura de prueba** lee los sensores sin guardar nada.

## 3. Ubicar las pantallas (automático) y calibrar

**Reconocimiento automático:** con **Seguir esta pantalla si se mueve** activado (viene así),
en la primera lectura la app **busca sola** las pantallas de los HTC-2 en la imagen y
asigna la de la izquierda a Sensor A y la de la derecha a Sensor B. Reconoce el **LCD gris
enmarcado por el frente negro** del HTC-2 comparándolo con su entorno inmediato, así que
funciona aunque el marco toque cables u objetos oscuros, y aunque los equipos estén
lejos, girados o en perspectiva.

**Distribución del HTC-2 (ya viene configurada):** fila 1 = temperatura (IN), fila 2 =
temperatura (OUT), fila 3 = reloj (izquierda) y **humedad** (derecha). Los dígitos se leen
con el contraste del LCD normalizado: el LCD reflectivo visto por webcam tiene poco
contraste (los dígitos apenas 15–30 niveles más oscuros que el fondo).

**Seguimiento:** en cada lectura (y cada 2,5 s en la vista previa) la app vuelve a ubicar
cada pantalla. Si alguien mueve un sensor o la cámara, el lector **se recentra solo** y
las regiones de los valores se mueven con la pantalla. Los dos sensores son idénticos: la
app no los confunde porque cada uno conserva la posición más cercana a la anterior. Si una
pantalla sale del encuadre queda **SENSOR NO DETECTADO** (recuadro rojo punteado) y se
recupera sola cuando vuelve. En el Dashboard, *Ubicación de la pantalla* muestra el estado.

Pestaña **Calibración** (para revisar o corregir):

1. **🔍 Detectar pantallas automáticamente**: marca en amarillo lo que encontró (#1, #2…)
   y asigna A y B. Si quedaron al revés: **Intercambiar A ↔ B**.
2. ¿No detectó alguna? Elige el sensor y **haz clic sobre su pantalla**: se ajusta sola
   alrededor del clic (precisión sub-píxel). Como último recurso, arrastra un rectángulo
   y mueve las 4 esquinas.
3. En la **vista rectificada**, elige un valor y dibuja su región alrededor de los dígitos;
   ajusta **dígitos** y **decimales**. Hazlo en un sensor y usa **Copiar regiones de valores
   al otro sensor** (son el mismo modelo).
4. Ajusta **Inclinación de los dígitos** hasta que las guías coincidan con la itálica del LCD.
5. Revisa *Lectura / Confianza* y pulsa **Guardar calibración** (guarda también la
   apariencia del equipo que usa el seguimiento).

**Consejos para la cámara:** usa **1920 × 1080** (viene por defecto) si los sensores se ven
pequeños; evita que el sol o una lámpara se refleje en el LCD; enfoca a la distancia de los
sensores. La lectura necesita que cada pantalla ocupe al menos ~8–10 % del ancho de la imagen.

## 4. Límites de producción

Pestaña **Sensores**: temperatura mínima/máxima (target_min / target_max) y humedad
mínima/máxima **por sensor**, y cuál temperatura controla las alertas (IN u OUT).
El sistema **no propone valores**: vacío = no configurado = sin alertas de rango.

## 5. Monitorear

**▶ Iniciar monitoreo** lee cada 1 minuto (configurable: 30 s, 1, 2, 5, 10, 15 min).
La cabecera muestra `LAST READING` y `NEXT READING`. Si la app se cierra con el
monitoreo en curso, se reanuda al abrirla otra vez. Mientras monitorea, el
equipo no debe suspenderse. La app pide a Chrome mantener la pantalla encendida.

Ciclo: fotograma → recorte del sensor y corrección de perspectiva → gris, reducción de
ruido, contraste → lectura de 7 segmentos → **validación** → comparación con el
histórico → guardado → eventos y alertas.

### Confianza y validación
- Cada valor tiene una confianza (0–100 %): **alta** ≥ 85, **media** ≥ 70, **baja** < 70 (configurable), o **inválida**.
- Solo las lecturas de confianza alta o media son **confiables**. Las demás se guardan como texto crudo, pero no entran en gráficas, estadísticas ni alertas críticas.
- `315` sin punto decimal solo se corrige a `31.5` si coincide con la lectura anterior. Queda marcado como `OCR_CORRECTION`; si no hay forma de confirmarlo, se marca `OCR_UNCERTAIN`.
- Un salto improbable entre lecturas se marca y se confirma con la siguiente lectura.
- `LL`/`HH` en el display se reporta tal cual, con aviso de verificar físicamente.

### Estados
NORMAL · ATENCIÓN · FUERA DE RANGO · SIN DATOS · LECTURA INCIERTA · CÁMARA DESCONECTADA · SENSOR NO DETECTADO.
Siempre se muestran con texto e ícono, no solo con color.

### Eventos
`TEMPERATURE_INCREASE/DECREASE`, `HUMIDITY_INCREASE/DECREASE` (umbral dentro de la
ventana de 60 min o entre lecturas consecutivas), `*_ABOVE_LIMIT/*_BELOW_LIMIT`
(CRITICAL, solo tras N lecturas confiables consecutivas), `RETURN_TO_RANGE`,
`READING_UNCHANGED`, `POSSIBLE_STALE_READING` (valores **e** imagen sin cambios),
`OCR_FAILURE`, `OCR_CORRECTION`, `OCR_UNCERTAIN`, `LOW_CONFIDENCE`,
`CAMERA_FAILURE`, `SENSOR_NOT_DETECTED`, `POSSIBLE_DISCONNECTION` (display sin
contraste), `DATA_GAP`.

El lenguaje es deliberadamente prudente: *posible evento ambiental*, *se requiere
verificación física*. El sistema **nunca** afirma que hubo un apagón o que falló
un bombillo.

## 6. Histórico, gráficas, alertas

- **Histórico:** tabla filtrable por fechas y sensor, con eventos y evidencia (snapshot) de cada lectura.
- **Gráficas:** temperatura y humedad (hoy, 24 h, 7 d, 30 d, personalizado), Sensor A y B, con los límites superpuestos. La línea se corta donde no hubo datos. Pasa el cursor o usa las flechas para ver cada valor.
- **Alertas:** INFO / WARNING / CRITICAL, se reconocen una por una o todas. Opcionalmente, notificaciones del sistema (*Configuración*).

## 7. Exportar Excel

**⤓ Exportar Excel** (cabecera, últimos 30 días), **Histórico** (rango filtrado) o
**Reportes** (un día). El archivo `.xlsx` tiene las hojas:

- `READINGS`: timestamp (fecha real de Excel), sensor, temperature_in/out, humidity, deltas, confidence, status, events, source, raw_text…
- `EVENTS`: timestamp, sensor, event_type, value, previous_value, delta, severity, description…
- `DAILY SUMMARY`: mín/máx/promedio de temperatura y humedad, lecturas, alertas, errores OCR, fuera de rango, cambios y periodos sin datos por día y sensor.
- `CONFIGURATION`: parámetros y límites vigentes.
- `STATISTICS`: media, desviación, percentiles y % en rango.

## 8. Reportes

**Reportes → ¿Hubo cambios importantes este día?** (también en el Dashboard):
cambios bruscos con horas y valores, tendencias, periodos fuera de rango y sin
datos, y lecturas sospechosas. **Generar reporte diario** produce un Markdown con
el resumen, los eventos y una conclusión descriptiva. Queda guardado y se puede descargar.
No emite diagnósticos biológicos.

## 9. Simulación y pruebas sin sensores

- **Cámara → Simulación:** dibuja dos HTC-2 ficticios y los procesa con el mismo OCR. Permite inyectar anomalías: caída o subida de temperatura, salto de humedad, valores congelados, sensor fuera del encuadre, pantalla apagada, ruido y cámara sin señal.
- **Configuración → Simulación:** genera 6 h a 7 días de histórico simulado con anomalías.
- **Cámara → Imagen estática:** carga una foto de un HTC-2 (hay una de ejemplo sintética) para probar la calibración y el OCR.

Todo lo simulado queda marcado como `simulación` (columna *source* del Excel,
aviso en los reportes) y se borra con **Borrar datos simulados**.

## 10. Privacidad y funcionamiento sin internet

- La cámara se procesa en el navegador. No se envía video, fotos ni datos a ningún servicio externo, y no hay OCR en la nube.
- Los datos quedan en IndexedDB del perfil de Chrome. La app pide almacenamiento persistente.
- Las fotos de evidencia son opcionales (OFF / solo alertas / todas) y se borran según la retención configurada (14 días por defecto).
- Como PWA instalada o como extensión, abre y funciona sin conexión. No hay sincronización con la nube: *Respaldo JSON* sirve para copiar los datos.

## Si la app no abre

- **«No se puede acceder a localhost»**: el servidor no está corriendo. Usa el acceso directo del escritorio (lo inicia solo) o `npm run monitor`. Una vez instalada como app (PWA), abre aunque el servidor esté apagado.
- **Pantalla «Cargando BioTeva Monitor…» que no cambia**: el equipo está muy cargado o un antivirus demora las conexiones locales; a los 20 s se muestra el motivo. Recarga con Ctrl+F5.
- **Mensaje rojo «no pudo iniciar»**: muestra el error exacto; copia el texto para soporte.
- **Tras editar `js/*.js`**: ejecuta `npm run build:monitor` (la página carga `js/monitor.bundle.js`, un solo archivo generado; un test avisa si quedó desactualizado).

## Limitaciones conocidas

- **Validado con imágenes sintéticas** y con una captura real de baja resolución del cuarto (ubicación de las pantallas); la lectura de dígitos aún no se ha probado con el video real a resolución completa.
- El reconocimiento automático puede marcar otros objetos oscuros rectangulares como candidatos; revisa la asignación la primera vez (o usa clic sobre la pantalla). El primer uso real debe incluir una calibración cuidadosa y una revisión de la confianza.
- El lector está hecho para dígitos de **7 segmentos**. Los reflejos fuertes sobre el LCD, el desenfoque o una cámara muy lejana bajan la confianza (y la app lo señala).
- La lectura depende de que la ventana esté abierta y el equipo encendido. Chrome puede espaciar lecturas en pestañas ocultas: conviene una ventana dedicada (app instalada).
- Los datos no se comparten entre navegadores o formas de abrir la app sin usar el respaldo.
- AM/PM de la hora del display no se lee (solo HH:MM). La hora está desactivada por defecto.
- La extensión se instala en modo desarrollador. Para publicarla en Chrome Web Store se necesita una cuenta de desarrollador.

## Pruebas

`npm test` incluye `tests/monitor/` (OCR, validación, eventos, estados, cambios,
resumen, reporte, simulación, Excel, gráficas) y `tests/contract/monitor-static.test.ts`.
