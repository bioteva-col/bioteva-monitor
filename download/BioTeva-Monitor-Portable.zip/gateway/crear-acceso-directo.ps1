# Crea el acceso directo "BioTeva Monitor" en el escritorio, apuntando a esta carpeta.
$dir = Split-Path -Parent $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $desktop 'BioTeva Monitor.lnk'))
$lnk.TargetPath = Join-Path $dir 'Abrir BioTeva Monitor.cmd'
$lnk.WorkingDirectory = $dir
$lnk.IconLocation = (Join-Path $dir 'app\icons\icon.ico') + ',0'
$lnk.WindowStyle = 7
$lnk.Description = 'BioTeva Monitor - monitoreo ambiental y control termico'
$lnk.Save()
'Listo: acceso directo "BioTeva Monitor" creado en el escritorio.'
