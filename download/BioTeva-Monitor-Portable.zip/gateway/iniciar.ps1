# BioTeva Monitor - lanzador instalado en %LOCALAPPDATA%\BioTeva (fuera de OneDrive/Descargas).
#   iniciar.ps1            abre la app (y arranca el gateway termico si hace falta)
#   iniciar.ps1 -Inicio    al encender el equipo: espera la red, abre la app y vigila el gateway
param([switch]$Inicio)
$ErrorActionPreference = 'SilentlyContinue'
$dir = $PSScriptRoot
# Instalado: <dir>\gateway\heater-gateway.mjs ; dentro del paquete portatil: junto a este archivo.
$gw = if (Test-Path (Join-Path $dir 'gateway\heater-gateway.mjs')) { Join-Path $dir 'gateway' } else { $dir }
$AppUrl = 'https://bioteva-col.github.io/bioteva-monitor/#dashboard'
$log = Join-Path $dir 'iniciar.log'
function Log($m) { Add-Content -Path $log -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $m) }

function Find-Node {
  $n = (Get-Command node -ErrorAction SilentlyContinue).Source
  if (-not $n) { $n = @("$env:ProgramFiles\nodejs\node.exe", "$env:LOCALAPPDATA\Programs\nodejs\node.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1 }
  return $n
}
function Gateway-Ok {
  try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 'http://127.0.0.1:4479/api/status' | Out-Null; return $true } catch { return $false }
}
function Start-Gateway {
  if (Gateway-Ok) { return }
  $node = Find-Node
  if (-not $node) { Log 'Sin Node.js: la app abre igual, sin control de lamparas.'; return }
  Start-Process -FilePath $node -ArgumentList ('"' + (Join-Path $gw 'heater-gateway.mjs') + '"') -WorkingDirectory $gw -WindowStyle Hidden
  Log 'Gateway termico iniciado.'
}
function Online {
  try { $c = New-Object Net.Sockets.TcpClient; $ok = $c.ConnectAsync('bioteva-col.github.io', 443).Wait(3000); $c.Close(); return $ok } catch { return $false }
}
function Open-App {
  $chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
              "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
              "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
  # Ventana propia de Chrome, perfil principal (ahi viven las lecturas). Sin internet la abre
  # igual: la app queda guardada en Chrome (modo sin conexion) tras la primera visita.
  if ($chrome) { Start-Process $chrome @('--profile-directory=Default', "--app=$AppUrl") } else { Start-Process $AppUrl }
  Log 'App abierta.'
}

Start-Gateway
if (-not $Inicio) { Open-App; exit 0 }

# Al iniciar sesion: esperar la red (hasta 2 min) para que la app cargue al dia.
for ($i = 0; $i -lt 40 -and -not (Online); $i++) { Start-Sleep -Seconds 3 }
Open-App
# Vigilante: si el gateway se cae, se reinicia (revisa cada minuto).
while ($true) { Start-Sleep -Seconds 60; Start-Gateway }
