' BioTeva Monitor - arranque al iniciar sesion SIN PowerShell (Windows a veces no deja
' iniciar PowerShell oculto desde la tarea programada: paso el 2026-10-22, error 0xFFFD0000).
'   wscript arrancar.vbs          mantiene vivo el servicio local (lamparas y localhost:4478)
'   wscript arrancar.vbs /abrir   ademas abre la app en su ventana de Chrome (ya)
'   wscript arrancar.vbs /inicio  al iniciar sesion: espera la red y abre la app
' Solo texto ASCII: wscript lee el archivo en la codificacion del sistema.
Option Explicit
Dim sh, fs, dir, gw, node, logf, abrir, inicio, i, url, chrome, rc, avisado
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
dir = fs.GetParentFolderName(WScript.ScriptFullName)
gw = dir & "\gateway"
If Not fs.FileExists(gw & "\heater-gateway.mjs") Then gw = dir
logf = dir & "\iniciar.log"
url = "https://bioteva-col.github.io/bioteva-monitor/#dashboard"
abrir = False : inicio = False
For i = 0 To WScript.Arguments.Count - 1
  If LCase(WScript.Arguments(i)) = "/abrir" Then abrir = True
  If LCase(WScript.Arguments(i)) = "/inicio" Then inicio = True : abrir = True
Next

Function ServicioOk()
  On Error Resume Next
  Dim x
  ServicioOk = False
  Set x = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  x.setTimeouts 2000, 2000, 2000, 2000
  x.open "GET", "http://127.0.0.1:4479/api/status", False
  x.send
  If Err.Number = 0 Then If x.status = 200 Then ServicioOk = True
End Function

Sub Log(m)
  On Error Resume Next
  Dim f
  Set f = fs.OpenTextFile(logf, 8, True)
  f.WriteLine Year(Now) & "-" & Right("0" & Month(Now), 2) & "-" & Right("0" & Day(Now), 2) & " " & FormatDateTime(Now, 4) & ":" & Right("0" & Second(Now), 2) & "  " & m
  f.Close
End Sub

Function FirstFile(list)
  Dim p
  FirstFile = ""
  For Each p In list
    p = sh.ExpandEnvironmentStrings(p)
    If fs.FileExists(p) Then FirstFile = p : Exit Function
  Next
End Function

node = FirstFile(Array("%ProgramFiles%\nodejs\node.exe", "%LOCALAPPDATA%\Programs\nodejs\node.exe", "%ProgramFiles(x86)%\nodejs\node.exe"))
chrome = FirstFile(Array("%ProgramFiles%\Google\Chrome\Application\chrome.exe", "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"))

If abrir Then
  ' dar tiempo a la red para que la app cargue al dia (sin red abre igual: queda guardada en Chrome)
  If inicio Then WScript.Sleep 15000
  If chrome <> "" Then
    sh.Run """" & chrome & """ --profile-directory=Default --app=" & url, 1, False
  Else
    sh.Run url, 1, False
  End If
  Log "App abierta (arranque)."
End If

If node = "" Then
  Log "Sin Node.js: la app funciona, sin control de lamparas."
  WScript.Quit 0
End If

' Vigilante: el servicio corre oculto; si se cierra, se vuelve a abrir. Si ya habia otro
' corriendo (puerto ocupado), node termina enseguida y se reintenta cada minuto sin ruido.
' Al abrir a mano: si el servicio ya funciona, ya hay un vigilante (no se duplica).
If abrir And Not inicio Then
  If ServicioOk() Then WScript.Quit 0
End If
Log "Servicio local iniciado (vigilante sin PowerShell)."
avisado = False
Do
  rc = sh.Run("""" & node & """ """ & gw & "\heater-gateway.mjs""", 0, True)
  If Not avisado Then
    Log "El servicio se detuvo (codigo " & rc & "); se reintenta cada minuto."
    avisado = True
  End If
  WScript.Sleep 60000
Loop
