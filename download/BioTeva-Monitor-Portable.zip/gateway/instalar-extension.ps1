# Copia la extension a una carpeta fija (no se borra con Descargas ni al mover el paquete)
# y deja la ruta en el portapapeles. Chrome NO permite que un programa instale ni abra
# chrome://extensions: los 3 clics finales los hace la persona.
param([switch]$NoOpen)
$ErrorActionPreference = 'Stop'
$src = Join-Path (Split-Path -Parent $PSScriptRoot) 'extension-chrome'
$dest = Join-Path $env:LOCALAPPDATA 'BioTeva\extension-chrome'
if (-not (Test-Path (Join-Path $src 'manifest.json'))) { $src = $dest }  # ya instalada: solo mostrar pasos
if (-not (Test-Path (Join-Path $src 'manifest.json'))) { Write-Error "No se encontro la carpeta extension-chrome junto a este archivo."; exit 1 }

if ($src -ne $dest) {
  New-Item -ItemType Directory -Force $dest | Out-Null
  robocopy $src $dest /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { Write-Error "No se pudo copiar la extension (robocopy $LASTEXITCODE)."; exit 1 }
}
Set-Clipboard -Value $dest
""
"La extension esta lista en:  $dest"
"(la ruta ya quedo copiada)"
""
"Ahora en Google Chrome (3 pasos, una sola vez):"
"  1. Escribe en la barra de direcciones:  chrome://extensions   y Enter."
"  2. Activa 'Modo de desarrollador' (interruptor arriba a la derecha)."
"  3. Pulsa 'Cargar descomprimida', pega la ruta con Ctrl+V arriba en la ventana,"
"     Enter, y 'Seleccionar carpeta'."
""
"Aparece 'BioTeva Monitor ambiental'. Fijala con el icono de rompecabezas."
"Si ya estaba instalada, pulsa la flecha circular (recargar) en su tarjeta."
if (-not $NoOpen) { Start-Process explorer.exe $dest }
exit 0
