# Copia la extension a una carpeta fija (no se borra con Descargas ni al mover el paquete)
# y abre chrome://extensions para cargarla. Chrome no permite que un programa la instale
# solo: el ultimo clic ("Cargar descomprimida") lo hace la persona.
param([switch]$NoOpen)
$ErrorActionPreference = 'Stop'
$src = Join-Path (Split-Path -Parent $PSScriptRoot) 'extension-chrome'
$dest = Join-Path $env:LOCALAPPDATA 'BioTeva\extension-chrome'
if (-not (Test-Path (Join-Path $src 'manifest.json'))) { Write-Error "No se encontro la carpeta extension-chrome junto a este archivo."; exit 1 }

New-Item -ItemType Directory -Force $dest | Out-Null
robocopy $src $dest /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Write-Error "No se pudo copiar la extension (robocopy $LASTEXITCODE)."; exit 1 }
Set-Clipboard -Value $dest
"Extension copiada en:"
"  $dest"
"(la ruta quedo copiada: en el dialogo de Chrome puedes pegarla con Ctrl+V)"
""
"Pasos en Chrome (se abre ahora):"
"  1. Activa 'Modo de desarrollador' (arriba a la derecha)."
"  2. Pulsa 'Cargar descomprimida'."
"  3. Pega la ruta (Ctrl+V) en la barra de la ventana, Enter, y 'Seleccionar carpeta'."
"  Si ya estaba instalada, pulsa el boton de recargar (flecha circular) de BioTeva Monitor."
if ($NoOpen) { exit 0 }

$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
            "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chrome) { Start-Process $chrome 'chrome://extensions' } else { "No se encontro Google Chrome: instalalo y abre chrome://extensions." }
Start-Process explorer.exe $dest
