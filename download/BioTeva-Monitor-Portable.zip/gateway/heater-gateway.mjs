/**
 * BioTeva — gateway térmico local.
 *
 * Ejecuta el termostato de cada caja y acciona enchufes TP-Link Kasa HS105 por la
 * red local (protocolo Kasa, TCP 9999). Corre en el computador de las cajas y
 * escucha SOLO en 127.0.0.1: el HS105 nunca se expone a internet.
 *
 *   npm run termico              → http://127.0.0.1:4479
 *
 * La app de monitoreo (cámara + OCR) le envía cada lectura de la caja; el gateway
 * decide con js/thermal.js (el mismo motor que usa el simulador de la app) y
 * aplica el apagado de seguridad aunque la ventana de la app se cierre: si dejan
 * de llegar lecturas, se aplica la estrategia configurada ante falla del sensor.
 *
 * Datos: %APPDATA%\BioTeva\termico (config.json, state.json, events.jsonl).
 * Sin dependencias.
 */
import { createServer } from "node:http";
import { connect } from "node:net";
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createContext, runInContext } from "node:vm";

const HERE = dirname(fileURLToPath(import.meta.url));

/** Carga el motor térmico compartido con la app (src/web/public/monitor/js/thermal.js). */
export function loadThermal() {
  const ctx = createContext({});
  // En el proyecto: src/web/public/monitor/js/thermal.js · en el paquete portátil: junto a este archivo.
  const candidates = [join(HERE, "thermal.js"), join(HERE, "..", "src", "web", "public", "monitor", "js", "thermal.js")];
  const path = candidates.find((c) => existsSync(c));
  if (!path) throw new Error("No se encontró thermal.js (motor del termostato)");
  runInContext(readFileSync(path, "utf8"), ctx);
  return ctx.MonThermal;
}

// ─────────────────────────── protocolo Kasa (HS105) ───────────────────────────

/** Cifrado "autokey" XOR del protocolo local de Kasa (clave inicial 171) con prefijo de longitud. */
export function kasaEncrypt(text) {
  const plain = Buffer.from(text, "utf8"), out = Buffer.alloc(plain.length + 4);
  out.writeUInt32BE(plain.length, 0);
  let key = 171;
  for (let i = 0; i < plain.length; i++) { key = key ^ plain[i]; out[i + 4] = key; }
  return out;
}
export function kasaDecrypt(buf) {
  const out = Buffer.alloc(buf.length);
  let key = 171;
  for (let i = 0; i < buf.length; i++) { out[i] = key ^ buf[i]; key = buf[i]; }
  return out.toString("utf8");
}

/** Envía un comando JSON a un enchufe Kasa y devuelve la respuesta (o lanza error). */
export function kasaSend(host, command, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    const sock = connect({ host, port: 9999 });
    const chunks = [];
    let expected = null;
    const timer = setTimeout(() => { sock.destroy(); reject(new Error("Sin respuesta del enchufe (" + host + ")")); }, timeoutMs);
    sock.on("connect", () => sock.write(kasaEncrypt(JSON.stringify(command))));
    sock.on("data", (d) => {
      chunks.push(d);
      const all = Buffer.concat(chunks);
      if (expected == null && all.length >= 4) expected = all.readUInt32BE(0);
      if (expected != null && all.length >= expected + 4) {
        clearTimeout(timer);
        sock.end();
        try { resolve(JSON.parse(kasaDecrypt(all.subarray(4, 4 + expected)))); } catch (e) { reject(new Error("Respuesta inválida del enchufe")); }
      }
    });
    sock.on("error", (e) => { clearTimeout(timer); reject(e); });
  });
}

/** Actuadores: HS105 real, simulado (pruebas sin hardware) o ninguno. */
export function makeDevice(cfg, sims) {
  const type = (cfg && cfg.type) || "none";
  if (type === "hs105") {
    return {
      type,
      async getState() {
        const r = await kasaSend(cfg.host, { system: { get_sysinfo: {} } });
        const relay = r && r.system && r.system.get_sysinfo && r.system.get_sysinfo.relay_state;
        if (relay !== 0 && relay !== 1) throw new Error("El enchufe no informó su estado");
        return relay === 1 ? "ON" : "OFF";
      },
      async set(on) { await kasaSend(cfg.host, { system: { set_relay_state: { state: on ? 1 : 0 } } }); },
      info: async () => { const r = await kasaSend(cfg.host, { system: { get_sysinfo: {} } }); const s = r.system.get_sysinfo; return { alias: s.alias, model: s.model, relay: s.relay_state, rssi: s.rssi }; },
    };
  }
  if (type === "sim") {
    const key = cfg.host || "sim";
    if (!sims[key]) sims[key] = { state: "OFF", fail: false };
    return {
      type,
      async getState() { if (sims[key].fail) throw new Error("Enchufe simulado inalcanzable"); return sims[key].state; },
      async set(on) { if (sims[key].fail) throw new Error("Enchufe simulado inalcanzable"); sims[key].state = on ? "ON" : "OFF"; },
      info: async () => ({ alias: "Simulado", model: "SIM-HS105", relay: sims[key].state === "ON" ? 1 : 0 }),
    };
  }
  return { type: "none", async getState() { return "UNKNOWN"; }, async set() { throw new Error("La caja no tiene enchufe configurado"); }, info: async () => null };
}

// ─────────────────────────── gateway ───────────────────────────

export function createGateway(opts = {}) {
  const T = opts.thermal || loadThermal();
  const now = opts.now || (() => Date.now());
  const dir = opts.dataDir;
  const sims = {};
  if (dir) mkdirSync(dir, { recursive: true });
  const file = (n) => join(dir, n);
  const read = (n, fallback) => { try { return dir && existsSync(file(n)) ? JSON.parse(readFileSync(file(n), "utf8")) : fallback; } catch { return fallback; } };
  const write = (n, v) => { if (dir) writeFileSync(file(n), JSON.stringify(v, null, 2)); };

  // Configuración inicial opcional (p. ej. la traída de otro computador en el paquete portátil).
  let initial = {};
  try { if (opts.initialConfigPath && existsSync(opts.initialConfigPath)) initial = JSON.parse(readFileSync(opts.initialConfigPath, "utf8")); } catch { initial = {}; }
  const config = Object.assign({ profiles: T.defaultProfiles(), control: T.defaultControl(), boxes: T.defaultBoxes() }, initial, read("config.json", {}));
  const state = read("state.json", {}); // por caja: heater, safety, lowSince, highSince, lastSwitchAt, onSince, onMsToday, day, reason, level
  const readings = {}; // por sensor, lecturas REALES (cámara): { out, in, humidity, ts, reliable, sameSince, source }
  const simReadings = {}; // por sensor, lecturas de simulación / imagen de prueba
  /** Un enchufe real (HS105) solo obedece lecturas reales; los simulados aceptan también las de prueba. */
  const readingFor = (box) => {
    const real = readings[box.sensorId], sim = simReadings[box.sensorId];
    if (box.heater && box.heater.type === "hs105") return real;
    return !real || (sim && sim.ts > real.ts) ? sim || real : real;
  };
  const events = [];
  const deviceHealth = {}; // por caja: ONLINE | UNREACHABLE

  const boxState = (id) => (state[id] = state[id] || { heater: "UNKNOWN", safety: false, lowSince: null, highSince: null, lastSwitchAt: null, onSince: null, onMsToday: 0, day: null, reason: null, level: "ok" });
  const profileOf = (box) => config.profiles.find((p) => p.id === box.profileId) || config.profiles[0];

  function logEvent(box, prev, nextHeater, reason, extra) {
    const r = readingFor(box) || {};
    const e = Object.assign({
      ts: now(), box_id: box.id, sensor_id: box.sensorId, heater_id: box.heater && box.heater.host ? box.heater.type + ":" + box.heater.host : (box.heater || {}).type,
      in_temperature: r.in ?? null, out_temperature: r.out ?? null, humidity: r.humidity ?? null,
      previous_heater_state: prev, new_heater_state: nextHeater, mode: box.mode, reason, message: T.REASONS[reason] || reason,
    }, extra || {});
    events.push(e);
    if (events.length > 5000) events.splice(0, events.length - 5000);
    if (dir) appendFileSync(file("events.jsonl"), JSON.stringify(e) + "\n");
    return e;
  }

  function accumulateOnTime(st, t) {
    const day = new Date(t).toDateString();
    if (st.day !== day) { st.day = day; st.onMsToday = 0; if (st.onSince) st.onSince = new Date(new Date(t).toDateString()).getTime(); }
    if (st.heater === "ON" && st.onSince) { st.onMsToday += t - st.onSince; st.onSince = t; }
  }

  /** Un ciclo del termostato para todas las cajas. */
  async function tick() {
    const t = now();
    for (const box of config.boxes) {
      if (!box.enabled) continue;
      const st = boxState(box.id), prof = profileOf(box), dev = makeDevice(box.heater, sims);
      accumulateOnTime(st, t);
      // estado real del enchufe (no se afirma nada que no se haya confirmado)
      if (dev.type !== "none") {
        try {
          const real = await dev.getState();
          if (real !== st.heater) { if (st.heater === "UNREACHABLE" || st.heater === "UNKNOWN") logEvent(box, st.heater, real, "AUTO_CONTROL", { note: "Estado del enchufe confirmado" }); st.heater = real; st.onSince = real === "ON" ? t : null; }
          if (deviceHealth[box.id] === "UNREACHABLE") deviceHealth[box.id] = "ONLINE";
          deviceHealth[box.id] = "ONLINE";
        } catch (e) {
          if (deviceHealth[box.id] !== "UNREACHABLE") logEvent(box, st.heater, "UNREACHABLE", "DEVICE_UNREACHABLE", { error: e.message, level: "critical" });
          deviceHealth[box.id] = "UNREACHABLE";
          st.heater = "UNREACHABLE";
        }
      } else deviceHealth[box.id] = "SIN ENCHUFE";

      const d = T.decide(box, prof, config.control, st, readingFor(box), t);
      const prevReason = st.reason;
      Object.assign(st, { safety: d.state.safety, lowSince: d.state.lowSince, highSince: d.state.highSince, sensorError: d.state.sensorError, reason: d.reason, level: d.level, notes: d.notes });
      if ((d.reason === "SAFETY_SHUTDOWN" || d.reason === "SENSOR_ERROR" || d.reason === "RECOVERY") && prevReason !== d.reason) {
        logEvent(box, st.heater, d.command || st.heater, d.reason === "SAFETY_SHUTDOWN" ? "CRITICAL_TEMPERATURE" : d.reason, { level: d.level, notes: d.notes });
      }
      if (d.command && d.command !== st.heater && dev.type !== "none") {
        const prev = st.heater;
        try {
          await dev.set(d.command === "ON");
          const confirmed = await dev.getState(); // verificar el resultado
          st.heater = confirmed;
          st.lastSwitchAt = t;
          st.onSince = confirmed === "ON" ? t : null;
          logEvent(box, prev, confirmed, d.reason, confirmed === d.command ? { level: d.level } : { level: "critical", error: "El enchufe no confirmó el comando " + d.command });
        } catch (e) {
          st.heater = "UNKNOWN"; // no afirmar que quedó apagado si no se pudo confirmar
          deviceHealth[box.id] = "UNREACHABLE";
          logEvent(box, prev, "UNKNOWN", "DEVICE_UNREACHABLE", { level: "critical", error: e.message, attempted: d.command });
        }
      }
    }
    write("state.json", state);
  }

  function status() {
    const t = now();
    return {
      ok: true, now: t, species: T.SPECIES, sources: T.SOURCES, control: config.control, profiles: config.profiles,
      boxes: config.boxes.map((b) => {
        const st = boxState(b.id), r = readingFor(b) || null;
        return Object.assign({}, b, {
          profile: profileOf(b), state: st, reading: r, sensor: T.sensorStatus(r, t, config.control),
          device: deviceHealth[b.id] || "DESCONOCIDO",
          onMinutesToday: Math.round(((st.onMsToday || 0) + (st.heater === "ON" && st.onSince ? t - st.onSince : 0)) / 60000),
        });
      }),
    };
  }

  // ───── API HTTP ─────
  const ALLOWED = [/^null$/, /^chrome-extension:\/\/[a-p]{32}$/, /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/, /^https:\/\/bioteva-col\.github\.io$/];
  const originOk = (o) => !o || ALLOWED.some((re) => re.test(o));

  async function handle(method, path, body, origin) {
    if (!originOk(origin)) return { status: 403, body: { error: "Origen no permitido" } };
    const send = (status, b) => ({ status, body: b });
    if (method === "GET" && path === "/api/status") return send(200, status());
    if (method === "GET" && path.startsWith("/api/events")) {
      const q = new URLSearchParams(path.split("?")[1] || ""), since = Number(q.get("since") || 0), boxId = q.get("box");
      return send(200, events.filter((e) => e.ts >= since && (!boxId || e.box_id === boxId)).slice(-1000));
    }
    if (method === "POST" && path === "/api/reading") {
      const sid = String(body.sensorId || "");
      if (!sid) return send(400, { error: "Falta sensorId" });
      const real = body.source === "camera", store = real ? readings : simReadings;
      const prev = store[sid];
      const out = typeof body.out === "number" && isFinite(body.out) ? body.out : null;
      store[sid] = { source: real ? "camera" : "simulation",
        out, in: typeof body.in === "number" ? body.in : null, humidity: typeof body.humidity === "number" ? body.humidity : null,
        reliable: body.reliable !== false && out != null, ts: now(),
        sameSince: prev && prev.out === out && out != null ? prev.sameSince : now(),
      };
      await tick(); // reaccionar de inmediato a la lectura nueva
      return send(200, status());
    }
    const modeM = path.match(/^\/api\/box\/([\w-]+)\/mode$/);
    if (method === "POST" && modeM) {
      const box = config.boxes.find((b) => b.id === modeM[1]);
      if (!box) return send(404, { error: "Caja no encontrada" });
      if (["AUTO", "MANUAL_ON", "MANUAL_OFF"].indexOf(body.mode) < 0) return send(400, { error: "Modo inválido" });
      const prevMode = box.mode;
      box.mode = body.mode;
      write("config.json", config);
      logEvent(box, boxState(box.id).heater, boxState(box.id).heater, body.mode === "AUTO" ? "AUTO_CONTROL" : body.mode, { note: "Modo " + prevMode + " → " + body.mode });
      await tick();
      return send(200, status());
    }
    if (method === "PUT" && path === "/api/config") {
      const errs = [];
      if (body.profiles) body.profiles.forEach((p) => T.validateProfile(p).forEach((e) => errs.push(p.name + ": " + e)));
      if (body.control) T.validateControl(body.control).forEach((e) => errs.push(e));
      if (body.boxes) body.boxes.forEach((b) => {
        if (!/^[\w-]{1,32}$/.test(b.id)) errs.push("Id de caja inválido: " + b.id);
        if (b.heater && b.heater.type === "hs105" && !/^[\w.-]{1,253}$/.test(b.heater.host || "")) errs.push(b.id + ": IP o nombre del HS105 inválido");
      });
      if (errs.length) return send(400, { error: errs.join(" · ") });
      if (body.profiles) config.profiles = body.profiles;
      if (body.control) config.control = Object.assign(config.control, body.control);
      if (body.boxes) config.boxes = body.boxes;
      write("config.json", config);
      await tick();
      return send(200, status());
    }
    if (method === "POST" && path === "/api/test-device") {
      try { return send(200, { ok: true, info: await makeDevice(body, sims).info() }); } catch (e) { return send(200, { ok: false, error: e.message }); }
    }
    if (method === "POST" && path === "/api/sim-plug") { // pruebas: simular corte del enchufe
      const key = body.host || "sim"; sims[key] = sims[key] || { state: "OFF", fail: false }; sims[key].fail = !!body.fail; return send(200, sims[key]);
    }
    return send(404, { error: "Ruta no encontrada" });
  }

  return { handle, tick, status, config, readings, events, sims };
}

// ─────────────────────────── servidor ───────────────────────────

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  const PORT = Number(process.env.TERMICO_PORT || 4479);
  const dataDir = process.env.BIOTEVA_TERMICO_DIR || join(process.env.APPDATA || join(HERE, ".."), "BioTeva", "termico");
  const gw = createGateway({ dataDir, initialConfigPath: join(HERE, "config-inicial.json") });
  const cors = (origin) => ({
    "access-control-allow-origin": origin || "*",
    "access-control-allow-methods": "GET, POST, PUT, OPTIONS",
    "access-control-allow-headers": "content-type, x-bioteva",
    "access-control-allow-private-network": "true", // Chrome: página → red local
    vary: "origin",
  });
  const server = createServer((req, res) => {
    const origin = req.headers.origin;
    if (req.method === "OPTIONS") { res.writeHead(204, cors(origin)); return res.end(); }
    // Las escrituras exigen un encabezado propio: fuerza preflight CORS (evita CSRF desde otros sitios).
    if (req.method !== "GET" && req.headers["x-bioteva"] !== "1") { res.writeHead(403, cors(origin)); return res.end('{"error":"Falta X-BioTeva"}'); }
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", async () => {
      let body = {};
      try { body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}; } catch { res.writeHead(400, cors(origin)); return res.end('{"error":"JSON inválido"}'); }
      try {
        const r = await gw.handle(req.method, req.url || "/", body, origin);
        res.writeHead(r.status, Object.assign({ "content-type": "application/json; charset=utf-8" }, cors(origin)));
        res.end(JSON.stringify(r.body));
      } catch (e) {
        res.writeHead(500, cors(origin));
        res.end(JSON.stringify({ error: e.message }));
      }
    });
  });
  server.on("error", (e) => { console.error(e.code === "EADDRINUSE" ? "El gateway térmico ya está corriendo en el puerto " + PORT + "." : e.message); process.exit(e.code === "EADDRINUSE" ? 0 : 1); });
  server.listen(PORT, "127.0.0.1", () => {
    console.log("BioTeva gateway térmico → http://127.0.0.1:" + PORT + "  (datos: " + dataDir + ")");
    console.log("Deja esta ventana abierta: aplica el termostato y la seguridad de las cajas.");
  });
  setInterval(() => gw.tick().catch((e) => console.error("tick:", e.message)), 5000);
}
