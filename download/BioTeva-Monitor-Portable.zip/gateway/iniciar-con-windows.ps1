# (Opcional) Inicia el gateway termico al iniciar sesion, aunque nadie abra la app.
# Quitar: este archivo con -Quitar, o borrar "BioTeva gateway termico" de shell:startup
param([switch]$Quitar)
$lnkPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'BioTeva gateway termico.lnk'
if ($Quitar) { Remove-Item $lnkPath -ErrorAction SilentlyContinue; 'Inicio automatico quitado.'; exit 0 }

$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { Write-Error 'Necesitas Node.js (https://nodejs.org) para el control de lamparas.'; exit 1 }
$dir = Split-Path -Parent $PSScriptRoot

$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($lnkPath)
$lnk.TargetPath = (Get-Command powershell).Source
$lnk.Arguments = "-NoProfile -WindowStyle Hidden -Command `"Start-Process -FilePath '$node' -ArgumentList 'gateway\heater-gateway.mjs' -WorkingDirectory '$dir' -WindowStyle Hidden`""
$lnk.WorkingDirectory = $dir
$lnk.WindowStyle = 7
$lnk.Save()
'Listo: el gateway termico se iniciara con Windows.'
