# Instala BioTeva Monitor en este computador para que funcione SIEMPRE:
#  - copia app, gateway y extension a %LOCALAPPDATA%\BioTeva (carpeta local fija);
#  - acceso directo "BioTeva Monitor" en el escritorio;
#  - inicio automatico al encender: abre la app y mantiene vivo el gateway termico;
#  - repara accesos directos viejos que apuntaban a http://localhost:4478 (ya no existe).
# Quitar:  instalar.ps1 -Quitar   (no borra lecturas ni configuracion)
param([switch]$Quitar)
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $PSScriptRoot              # raiz del paquete portatil
$dest = Join-Path $env:LOCALAPPDATA 'BioTeva'
$ws = New-Object -ComObject WScript.Shell
$startupLnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'BioTeva Monitor.lnk'
$oldStartup = Join-Path ([Environment]::GetFolderPath('Startup')) 'BioTeva gateway termico.lnk'
$desktopLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'BioTeva Monitor.lnk'
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

if ($Quitar) {
  Remove-Item $startupLnk, $oldStartup -ErrorAction SilentlyContinue
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*BioTeva\iniciar.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
  'Inicio automatico quitado. (Las lecturas y la configuracion se conservan.)'; exit 0
}

# 1. copiar a la carpeta local fija
New-Item -ItemType Directory -Force $dest | Out-Null
foreach ($d in 'app', 'gateway', 'extension-chrome', 'docs') {
  if (Test-Path (Join-Path $src $d)) {
    robocopy (Join-Path $src $d) (Join-Path $dest $d) /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "No se pudo copiar $d (robocopy $LASTEXITCODE)" }
  }
}
Copy-Item (Join-Path $PSScriptRoot 'iniciar.ps1') (Join-Path $dest 'iniciar.ps1') -Force
$ico = Join-Path $dest 'app\icons\icon.ico'

function New-Lnk($path, $extra, $desc) {
  $l = $ws.CreateShortcut($path)
  $l.TargetPath = $ps
  $l.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$dest\iniciar.ps1`" $extra"
  $l.WorkingDirectory = $dest
  $l.IconLocation = "$ico,0"
  $l.WindowStyle = 7
  $l.Description = $desc
  $l.Save()
}

# 2. escritorio + inicio automatico (reemplaza el inicio viejo que solo arrancaba el gateway)
New-Lnk $desktopLnk '' 'BioTeva Monitor - monitoreo ambiental y control termico'
Remove-Item $oldStartup -ErrorAction SilentlyContinue
New-Lnk $startupLnk '-Inicio' 'BioTeva Monitor - abre la app al encender y vigila el gateway termico'

# 3. reparar accesos directos viejos (app instalada desde http://localhost:4478, que ya no existe)
$fixed = 0
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))
foreach ($p in $places) {
  # Todos los accesos "BioTeva Monitor*" (apps de Chrome viejas, lanzadores anteriores) pasan a este lanzador.
  Get-ChildItem $p -Filter 'BioTeva Monitor*.lnk' -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.FullName -ne $desktopLnk -and $_.FullName -ne $startupLnk } | ForEach-Object {
    New-Lnk $_.FullName '' 'BioTeva Monitor'; $fixed++
  }
}

"Instalado en $dest"
" - Escritorio: 'BioTeva Monitor'"
" - Al encender el equipo: se abre la app y el gateway termico queda vigilado."
if ($fixed) { " - Accesos directos viejos reparados: $fixed" }
if (-not (Get-Command node -ErrorAction SilentlyContinue) -and -not (Test-Path "$env:ProgramFiles\nodejs\node.exe")) { " ! Sin Node.js: la app funciona, pero sin control de lamparas (instalar desde https://nodejs.org)." }
exit 0
