﻿# Instala BioTeva Monitor en este computador para que funcione SIEMPRE:
#  - copia app, gateway y extension a %LOCALAPPDATA%\BioTeva (carpeta local fija);
#  - acceso directo "BioTeva Monitor" en el escritorio;
#  - inicio automatico al iniciar sesion (tarea programada): abre la app y mantiene vivo el servicio local;
#  - repara accesos directos viejos que apuntaban a http://localhost:4478.
# Quitar:  instalar.ps1 -Quitar   (no borra lecturas ni configuracion)
param([switch]$Quitar)
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $PSScriptRoot              # raiz del paquete portatil
$dest = Join-Path $env:LOCALAPPDATA 'BioTeva'
$ws = New-Object -ComObject WScript.Shell
$startupLnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'BioTeva Monitor.lnk'
$oldStartup = Join-Path ([Environment]::GetFolderPath('Startup')) 'BioTeva gateway termico.lnk'
$desktopLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'BioTeva Monitor.lnk'
# El arranque usa wscript + arrancar.vbs (sin PowerShell): el 2026-10-22 Windows no dejo iniciar
# PowerShell oculto desde la tarea programada (0xFFFD0000) y la app quedo sin servicio.
$wscript = Join-Path $env:SystemRoot 'System32\wscript.exe'
$taskName = 'BioTeva Monitor'

if ($Quitar) {
  Remove-Item $startupLnk, $oldStartup -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
  Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*BioTeva\iniciar.ps1*' -or $_.CommandLine -like '*BioTeva\arrancar.vbs*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
  'Inicio automatico quitado. (Las lecturas y la configuracion se conservan.)'; exit 0
}

# 1. copiar a la carpeta local fija
New-Item -ItemType Directory -Force $dest | Out-Null
foreach ($d in 'app', 'gateway', 'extension-chrome', 'docs') {
  if (Test-Path (Join-Path $src $d)) {
    robocopy (Join-Path $src $d) (Join-Path $dest $d) /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "No se pudo copiar $d (robocopy $LASTEXITCODE)" }
  }
}
Copy-Item (Join-Path $PSScriptRoot 'iniciar.ps1') (Join-Path $dest 'iniciar.ps1') -Force
Copy-Item (Join-Path $PSScriptRoot 'arrancar.vbs') (Join-Path $dest 'arrancar.vbs') -Force
$ico = Join-Path $dest 'app\icons\icon.ico'

function New-Lnk($path, $extra, $desc) {
  $l = $ws.CreateShortcut($path)
  $l.TargetPath = $wscript
  $l.Arguments = "`"$dest\arrancar.vbs`" $extra"
  $l.WorkingDirectory = $dest
  $l.IconLocation = "$ico,0"
  $l.Description = $desc
  $l.Save()
}

# 2. escritorio + inicio automatico con TAREA PROGRAMADA al iniciar sesion (la carpeta Inicio
#    de Windows a veces no ejecuta el acceso: paso el 2026-10-20). Sin administrador.
New-Lnk $desktopLnk '/abrir' 'BioTeva Monitor - monitoreo ambiental y control termico'
Remove-Item $oldStartup -ErrorAction SilentlyContinue
# respaldo: si la tarea desaparece (el 2026-10-22 se borro sola minutos despues de crearla;
# posible antivirus o limpiador), la carpeta Inicio al menos levanta el servicio (sin ventana)
New-Lnk $startupLnk '' 'BioTeva Monitor - servicio local (respaldo de la tarea programada)'
$act = New-ScheduledTaskAction -Execute $wscript -Argument "`"$dest\arrancar.vbs`" /inicio"
$trg = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
$prn = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $taskName -Action $act -Trigger $trg -Settings $set -Principal $prn -Description 'BioTeva Monitor: al iniciar sesion abre la app y mantiene el servicio local (lamparas y localhost:4478).' -Force | Out-Null

# 3. reparar accesos directos viejos (app instalada desde http://localhost:4478)
$fixed = 0
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))
foreach ($p in $places) {
  # Todos los accesos "BioTeva Monitor*" (apps de Chrome viejas, lanzadores anteriores) pasan a este lanzador.
  Get-ChildItem $p -Filter 'BioTeva Monitor*.lnk' -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.FullName -ne $desktopLnk -and $_.FullName -ne $startupLnk } | ForEach-Object {
    New-Lnk $_.FullName '/abrir' 'BioTeva Monitor'; $fixed++
  }
}

# 4. dejar el servicio local funcionando YA (sin esto nadie atiende http://localhost:4478 hasta
#    el proximo inicio de sesion y la app vieja de Chrome muestra "no se puede acceder")
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*BioTeva\iniciar.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Process -FilePath $wscript -ArgumentList "`"$dest\arrancar.vbs`""

"Instalado en $dest"
" - Escritorio: 'BioTeva Monitor'"
" - Al iniciar sesion (tarea programada '$taskName'): se abre la app y el servicio local queda vigilado."
if ($fixed) { " - Accesos directos viejos reparados: $fixed" }
if (-not (Get-Command node -ErrorAction SilentlyContinue) -and -not (Test-Path "$env:ProgramFiles\nodejs\node.exe")) { " ! Sin Node.js: la app funciona, pero sin control de lamparas (instalar desde https://nodejs.org)." }
exit 0
