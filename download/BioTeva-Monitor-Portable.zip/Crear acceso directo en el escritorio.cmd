@echo off
rem Crea el acceso directo "BioTeva Monitor" (con su icono) en el escritorio de este computador.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File gateway\crear-acceso-directo.ps1
pause
